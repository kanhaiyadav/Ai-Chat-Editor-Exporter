var content = (function() {
  "use strict";
  function defineContentScript(definition2) {
    return definition2;
  }
  const definition = defineContentScript({
    matches: ["https://chatgpt.com/*", "https://chat.openai.com/*"],
    main() {
      let currentUrl = location.href;
      let buttonCheckInterval = null;
      function isOnChatPage() {
        return location.href.includes("/c/") || location.href.includes("/g/");
      }
      function insertExportButton() {
        if (!isOnChatPage()) {
          console.log("Not on a chat page, skipping button insertion");
          return;
        }
        const headerDiv = document.querySelector(
          "#conversation-header-actions"
        );
        if (headerDiv && !document.querySelector("#export-chat-button")) {
          const exportButton = document.createElement("button");
          exportButton.id = "export-chat-button";
          exportButton.className = "btn relative btn-ghost text-token-text-primary mx-2";
          exportButton.setAttribute("aria-label", "Export Chat");
          exportButton.innerHTML = `
                    <div class="flex w-full items-center justify-center gap-1.5">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
                             fill="none" stroke="currentColor" stroke-width="2"
                             stroke-linecap="round" stroke-linejoin="round"
                             class="w-4 h-4">
                            <path d="M13 11L21.2 2.8" />
                            <path d="M22 6.8V2H17.2" />
                            <path d="M11 2H9C4 2 2 4 2 9V15C2 20 4 22 9 22H15C20 22 22 20 22 15V13" />
                        </svg>
                        <span>Export Chat</span>
                    </div>
                `;
          headerDiv.prepend(exportButton);
          exportButton.addEventListener("click", () => {
            console.log("Extracting chat data...");
            try {
              let title = "";
              const activeLink = document.querySelector(
                'nav[aria-label="Chat history"] a[data-active]'
              );
              if (activeLink) {
                title = activeLink.textContent?.trim() || "";
              }
              const turns = document.querySelectorAll(
                '[data-testid^="conversation-turn"]'
              );
              const messages = [];
              turns.forEach((turn) => {
                const isUser = turn.querySelector(
                  '[data-message-author-role="user"]'
                );
                const isAssistant = turn.querySelector(
                  '[data-message-author-role="assistant"]'
                );
                let role = "unknown";
                let content2 = "";
                let images = [];
                let attachments = [];
                if (isUser) {
                  role = "user";
                  const userBubble = turn.querySelector(
                    ".user-message-bubble-color, [data-multiline]"
                  );
                  content2 = userBubble?.textContent?.trim() || "";
                  const uploadedImages = turn.querySelectorAll(
                    'img[alt="Uploaded image"]'
                  );
                  uploadedImages.forEach((img) => {
                    const src = img.src;
                    if (src && !images.includes(src)) {
                      images.push(src);
                    }
                  });
                  const attachmentLinks = turn.querySelectorAll(
                    'a[target="_blank"][rel="noreferrer"]'
                  );
                  attachmentLinks.forEach((link) => {
                    const nameEl = link.querySelector(
                      ".truncate.font-semibold"
                    );
                    const typeEl = link.querySelector(
                      ".text-token-text-secondary.truncate"
                    );
                    if (nameEl) {
                      const fileName = nameEl.textContent?.trim() || "Unknown";
                      const fileType = typeEl?.textContent?.trim() || "File";
                      attachments.push({
                        name: fileName,
                        url: "",
                        type: fileType
                      });
                    }
                  });
                  const fileContainers = turn.querySelectorAll(
                    '[class*="file"], [class*="document"]'
                  );
                  fileContainers.forEach((container) => {
                    const svgParent = container.querySelector("svg");
                    if (svgParent) {
                      const parent = container.closest("a");
                      if (parent && parent.hasAttribute("href")) {
                        const href = parent.getAttribute("href");
                        if (href) {
                          const nameEl = container.querySelector(
                            ".truncate.font-semibold"
                          );
                          const typeEl = container.querySelector(
                            ".text-token-text-secondary.truncate"
                          );
                          if (nameEl && !attachments.some(
                            (a) => a.name === nameEl.textContent?.trim()
                          )) {
                            attachments.push({
                              name: nameEl.textContent?.trim() || "Unknown",
                              url: href,
                              type: typeEl?.textContent?.trim() || "File"
                            });
                          }
                        }
                      }
                    }
                  });
                } else {
                  role = "assistant";
                  const assistantContent = turn.querySelector(
                    '[data-message-author-role="assistant"]'
                  );
                  content2 = assistantContent?.innerHTML?.trim() || "";
                  const imageElements = turn.querySelectorAll(
                    'img[alt="Generated image"]'
                  );
                  imageElements.forEach((img) => {
                    const src = img.src;
                    if (src && !images.includes(src)) {
                      images.push(src);
                    }
                  });
                }
                if (content2 || images.length > 0 || attachments.length > 0) {
                  const message = {
                    role,
                    content: content2
                  };
                  if (images.length > 0) {
                    message.images = images;
                  }
                  if (attachments.length > 0) {
                    message.attachments = attachments;
                  }
                  messages.push(message);
                }
              });
              const iframes = document.querySelectorAll(
                'iframe[src*="backend-api/estuary/content"]'
              );
              iframes.forEach((iframe) => {
                const src = iframe.src;
                const title2 = iframe.title;
                if (title2 && src) {
                  const lastUserMessage = messages.filter((m) => m.role === "user").pop();
                  if (lastUserMessage && lastUserMessage.attachments) {
                    const attachment = lastUserMessage.attachments.find(
                      (a) => a.name === title2
                    );
                    if (attachment && !attachment.url) {
                      attachment.url = src;
                    }
                  }
                }
              });
              chrome.storage.local.set(
                {
                  chatData: {
                    title,
                    messages,
                    source: "chatgpt"
                  },
                  savedChatId: null,
                  pdfSettings: null
                },
                () => {
                  chrome.runtime.sendMessage({
                    action: "openOptions"
                  });
                  console.log("Chat data saved:", messages);
                }
              );
            } catch (error) {
              console.error("Error extracting chat data:", error);
              alert("Error extracting chat data. Please try again.");
            }
          });
          console.log("✅ Export Chat button inserted successfully");
          if (buttonCheckInterval) {
            clearInterval(buttonCheckInterval);
            buttonCheckInterval = null;
          }
        }
      }
      function checkUrlChange() {
        if (location.href !== currentUrl) {
          console.log(
            "URL changed from",
            currentUrl,
            "to",
            location.href
          );
          currentUrl = location.href;
          const existingButton = document.querySelector(
            "#export-chat-button"
          );
          if (existingButton && !isOnChatPage()) {
            existingButton.remove();
            console.log("Removed button - not on chat page");
          }
          if (isOnChatPage()) {
            console.log(
              "Navigated to chat page, waiting for header..."
            );
            if (buttonCheckInterval) {
              clearInterval(buttonCheckInterval);
            }
            buttonCheckInterval = window.setInterval(() => {
              insertExportButton();
            }, 300);
            setTimeout(() => {
              if (buttonCheckInterval) {
                clearInterval(buttonCheckInterval);
                buttonCheckInterval = null;
              }
            }, 15e3);
          }
        }
      }
      if (isOnChatPage()) {
        console.log("Already on chat page, starting button insertion...");
        buttonCheckInterval = window.setInterval(() => {
          insertExportButton();
        }, 300);
        setTimeout(() => {
          if (buttonCheckInterval) {
            clearInterval(buttonCheckInterval);
            buttonCheckInterval = null;
          }
        }, 15e3);
      }
      const observer = new MutationObserver(() => {
        checkUrlChange();
        if (isOnChatPage() && !document.querySelector("#export-chat-button")) {
          insertExportButton();
        }
      });
      observer.observe(document.body, {
        childList: true,
        subtree: true
      });
      setInterval(checkUrlChange, 1e3);
      console.log("✅ Content script initialized - watching for chat pages");
    }
  });
  const browser$1 = globalThis.browser?.runtime?.id ? globalThis.browser : globalThis.chrome;
  const browser = browser$1;
  function print$1(method, ...args) {
    if (typeof args[0] === "string") {
      const message = args.shift();
      method(`[wxt] ${message}`, ...args);
    } else {
      method("[wxt]", ...args);
    }
  }
  const logger$1 = {
    debug: (...args) => print$1(console.debug, ...args),
    log: (...args) => print$1(console.log, ...args),
    warn: (...args) => print$1(console.warn, ...args),
    error: (...args) => print$1(console.error, ...args)
  };
  class WxtLocationChangeEvent extends Event {
    constructor(newUrl, oldUrl) {
      super(WxtLocationChangeEvent.EVENT_NAME, {});
      this.newUrl = newUrl;
      this.oldUrl = oldUrl;
    }
    static EVENT_NAME = getUniqueEventName("wxt:locationchange");
  }
  function getUniqueEventName(eventName) {
    return `${browser?.runtime?.id}:${"content"}:${eventName}`;
  }
  function createLocationWatcher(ctx) {
    let interval;
    let oldUrl;
    return {
      /**
       * Ensure the location watcher is actively looking for URL changes. If it's already watching,
       * this is a noop.
       */
      run() {
        if (interval != null) return;
        oldUrl = new URL(location.href);
        interval = ctx.setInterval(() => {
          let newUrl = new URL(location.href);
          if (newUrl.href !== oldUrl.href) {
            window.dispatchEvent(new WxtLocationChangeEvent(newUrl, oldUrl));
            oldUrl = newUrl;
          }
        }, 1e3);
      }
    };
  }
  class ContentScriptContext {
    constructor(contentScriptName, options) {
      this.contentScriptName = contentScriptName;
      this.options = options;
      this.abortController = new AbortController();
      if (this.isTopFrame) {
        this.listenForNewerScripts({ ignoreFirstEvent: true });
        this.stopOldScripts();
      } else {
        this.listenForNewerScripts();
      }
    }
    static SCRIPT_STARTED_MESSAGE_TYPE = getUniqueEventName(
      "wxt:content-script-started"
    );
    isTopFrame = window.self === window.top;
    abortController;
    locationWatcher = createLocationWatcher(this);
    receivedMessageIds = /* @__PURE__ */ new Set();
    get signal() {
      return this.abortController.signal;
    }
    abort(reason) {
      return this.abortController.abort(reason);
    }
    get isInvalid() {
      if (browser.runtime.id == null) {
        this.notifyInvalidated();
      }
      return this.signal.aborted;
    }
    get isValid() {
      return !this.isInvalid;
    }
    /**
     * Add a listener that is called when the content script's context is invalidated.
     *
     * @returns A function to remove the listener.
     *
     * @example
     * browser.runtime.onMessage.addListener(cb);
     * const removeInvalidatedListener = ctx.onInvalidated(() => {
     *   browser.runtime.onMessage.removeListener(cb);
     * })
     * // ...
     * removeInvalidatedListener();
     */
    onInvalidated(cb) {
      this.signal.addEventListener("abort", cb);
      return () => this.signal.removeEventListener("abort", cb);
    }
    /**
     * Return a promise that never resolves. Useful if you have an async function that shouldn't run
     * after the context is expired.
     *
     * @example
     * const getValueFromStorage = async () => {
     *   if (ctx.isInvalid) return ctx.block();
     *
     *   // ...
     * }
     */
    block() {
      return new Promise(() => {
      });
    }
    /**
     * Wrapper around `window.setInterval` that automatically clears the interval when invalidated.
     *
     * Intervals can be cleared by calling the normal `clearInterval` function.
     */
    setInterval(handler, timeout) {
      const id = setInterval(() => {
        if (this.isValid) handler();
      }, timeout);
      this.onInvalidated(() => clearInterval(id));
      return id;
    }
    /**
     * Wrapper around `window.setTimeout` that automatically clears the interval when invalidated.
     *
     * Timeouts can be cleared by calling the normal `setTimeout` function.
     */
    setTimeout(handler, timeout) {
      const id = setTimeout(() => {
        if (this.isValid) handler();
      }, timeout);
      this.onInvalidated(() => clearTimeout(id));
      return id;
    }
    /**
     * Wrapper around `window.requestAnimationFrame` that automatically cancels the request when
     * invalidated.
     *
     * Callbacks can be canceled by calling the normal `cancelAnimationFrame` function.
     */
    requestAnimationFrame(callback) {
      const id = requestAnimationFrame((...args) => {
        if (this.isValid) callback(...args);
      });
      this.onInvalidated(() => cancelAnimationFrame(id));
      return id;
    }
    /**
     * Wrapper around `window.requestIdleCallback` that automatically cancels the request when
     * invalidated.
     *
     * Callbacks can be canceled by calling the normal `cancelIdleCallback` function.
     */
    requestIdleCallback(callback, options) {
      const id = requestIdleCallback((...args) => {
        if (!this.signal.aborted) callback(...args);
      }, options);
      this.onInvalidated(() => cancelIdleCallback(id));
      return id;
    }
    addEventListener(target, type, handler, options) {
      if (type === "wxt:locationchange") {
        if (this.isValid) this.locationWatcher.run();
      }
      target.addEventListener?.(
        type.startsWith("wxt:") ? getUniqueEventName(type) : type,
        handler,
        {
          ...options,
          signal: this.signal
        }
      );
    }
    /**
     * @internal
     * Abort the abort controller and execute all `onInvalidated` listeners.
     */
    notifyInvalidated() {
      this.abort("Content script context invalidated");
      logger$1.debug(
        `Content script "${this.contentScriptName}" context invalidated`
      );
    }
    stopOldScripts() {
      window.postMessage(
        {
          type: ContentScriptContext.SCRIPT_STARTED_MESSAGE_TYPE,
          contentScriptName: this.contentScriptName,
          messageId: Math.random().toString(36).slice(2)
        },
        "*"
      );
    }
    verifyScriptStartedEvent(event) {
      const isScriptStartedEvent = event.data?.type === ContentScriptContext.SCRIPT_STARTED_MESSAGE_TYPE;
      const isSameContentScript = event.data?.contentScriptName === this.contentScriptName;
      const isNotDuplicate = !this.receivedMessageIds.has(event.data?.messageId);
      return isScriptStartedEvent && isSameContentScript && isNotDuplicate;
    }
    listenForNewerScripts(options) {
      let isFirst = true;
      const cb = (event) => {
        if (this.verifyScriptStartedEvent(event)) {
          this.receivedMessageIds.add(event.data.messageId);
          const wasFirst = isFirst;
          isFirst = false;
          if (wasFirst && options?.ignoreFirstEvent) return;
          this.notifyInvalidated();
        }
      };
      addEventListener("message", cb);
      this.onInvalidated(() => removeEventListener("message", cb));
    }
  }
  function initPlugins() {
  }
  function print(method, ...args) {
    if (typeof args[0] === "string") {
      const message = args.shift();
      method(`[wxt] ${message}`, ...args);
    } else {
      method("[wxt]", ...args);
    }
  }
  const logger = {
    debug: (...args) => print(console.debug, ...args),
    log: (...args) => print(console.log, ...args),
    warn: (...args) => print(console.warn, ...args),
    error: (...args) => print(console.error, ...args)
  };
  const result = (async () => {
    try {
      initPlugins();
      const { main, ...options } = definition;
      const ctx = new ContentScriptContext("content", options);
      return await main(ctx);
    } catch (err) {
      logger.error(
        `The content script "${"content"}" crashed on startup!`,
        err
      );
      throw err;
    }
  })();
  return result;
})();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29udGVudC5qcyIsInNvdXJjZXMiOlsiLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3d4dC9kaXN0L3V0aWxzL2RlZmluZS1jb250ZW50LXNjcmlwdC5tanMiLCIuLi8uLi8uLi9lbnRyeXBvaW50cy9jb250ZW50LnRzIiwiLi4vLi4vLi4vbm9kZV9tb2R1bGVzL0B3eHQtZGV2L2Jyb3dzZXIvc3JjL2luZGV4Lm1qcyIsIi4uLy4uLy4uL25vZGVfbW9kdWxlcy93eHQvZGlzdC9icm93c2VyLm1qcyIsIi4uLy4uLy4uL25vZGVfbW9kdWxlcy93eHQvZGlzdC91dGlscy9pbnRlcm5hbC9sb2dnZXIubWpzIiwiLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3d4dC9kaXN0L3V0aWxzL2ludGVybmFsL2N1c3RvbS1ldmVudHMubWpzIiwiLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3d4dC9kaXN0L3V0aWxzL2ludGVybmFsL2xvY2F0aW9uLXdhdGNoZXIubWpzIiwiLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3d4dC9kaXN0L3V0aWxzL2NvbnRlbnQtc2NyaXB0LWNvbnRleHQubWpzIl0sInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBmdW5jdGlvbiBkZWZpbmVDb250ZW50U2NyaXB0KGRlZmluaXRpb24pIHtcbiAgcmV0dXJuIGRlZmluaXRpb247XG59XG4iLCJleHBvcnQgZGVmYXVsdCBkZWZpbmVDb250ZW50U2NyaXB0KHtcbiAgICBtYXRjaGVzOiBbXCJodHRwczovL2NoYXRncHQuY29tLypcIiwgXCJodHRwczovL2NoYXQub3BlbmFpLmNvbS8qXCJdLFxuICAgIG1haW4oKSB7XG4gICAgICAgIGxldCBjdXJyZW50VXJsID0gbG9jYXRpb24uaHJlZjtcbiAgICAgICAgbGV0IGJ1dHRvbkNoZWNrSW50ZXJ2YWw6IG51bWJlciB8IG51bGwgPSBudWxsO1xuXG4gICAgICAgIC8vIEZ1bmN0aW9uIHRvIGNoZWNrIGlmIHdlJ3JlIG9uIGEgY2hhdCBwYWdlXG4gICAgICAgIGZ1bmN0aW9uIGlzT25DaGF0UGFnZSgpIHtcbiAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgbG9jYXRpb24uaHJlZi5pbmNsdWRlcyhcIi9jL1wiKSB8fCBsb2NhdGlvbi5ocmVmLmluY2x1ZGVzKFwiL2cvXCIpXG4gICAgICAgICAgICApO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gRnVuY3Rpb24gdG8gaW5zZXJ0IHRoZSBidXR0b25cbiAgICAgICAgZnVuY3Rpb24gaW5zZXJ0RXhwb3J0QnV0dG9uKCkge1xuICAgICAgICAgICAgLy8gT25seSBpbnNlcnQgYnV0dG9uIGlmIHdlJ3JlIG9uIGEgY2hhdCBwYWdlXG4gICAgICAgICAgICBpZiAoIWlzT25DaGF0UGFnZSgpKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJOb3Qgb24gYSBjaGF0IHBhZ2UsIHNraXBwaW5nIGJ1dHRvbiBpbnNlcnRpb25cIik7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBjb25zdCBoZWFkZXJEaXYgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFxuICAgICAgICAgICAgICAgIFwiI2NvbnZlcnNhdGlvbi1oZWFkZXItYWN0aW9uc1wiXG4gICAgICAgICAgICApO1xuXG4gICAgICAgICAgICAvLyBDaGVjayBpZiBoZWFkZXIgZXhpc3RzIGFuZCBidXR0b24gZG9lc24ndCBhbHJlYWR5IGV4aXN0XG4gICAgICAgICAgICBpZiAoaGVhZGVyRGl2ICYmICFkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiI2V4cG9ydC1jaGF0LWJ1dHRvblwiKSkge1xuICAgICAgICAgICAgICAgIC8vIENyZWF0ZSB0aGUgRXhwb3J0IENoYXQgYnV0dG9uXG4gICAgICAgICAgICAgICAgY29uc3QgZXhwb3J0QnV0dG9uID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImJ1dHRvblwiKTtcbiAgICAgICAgICAgICAgICBleHBvcnRCdXR0b24uaWQgPSBcImV4cG9ydC1jaGF0LWJ1dHRvblwiO1xuICAgICAgICAgICAgICAgIGV4cG9ydEJ1dHRvbi5jbGFzc05hbWUgPVxuICAgICAgICAgICAgICAgICAgICBcImJ0biByZWxhdGl2ZSBidG4tZ2hvc3QgdGV4dC10b2tlbi10ZXh0LXByaW1hcnkgbXgtMlwiO1xuICAgICAgICAgICAgICAgIGV4cG9ydEJ1dHRvbi5zZXRBdHRyaWJ1dGUoXCJhcmlhLWxhYmVsXCIsIFwiRXhwb3J0IENoYXRcIik7XG5cbiAgICAgICAgICAgICAgICAvLyBBZGQgaWNvbiArIHRleHRcbiAgICAgICAgICAgICAgICBleHBvcnRCdXR0b24uaW5uZXJIVE1MID0gYFxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCB3LWZ1bGwgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzdmcgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHN0cm9rZS13aWR0aD1cIjJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHJva2UtbGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlLWxpbmVqb2luPVwicm91bmRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cInctNCBoLTRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cGF0aCBkPVwiTTEzIDExTDIxLjIgMi44XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cGF0aCBkPVwiTTIyIDYuOFYySDE3LjJcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwYXRoIGQ9XCJNMTEgMkg5QzQgMiAyIDQgMiA5VjE1QzIgMjAgNCAyMiA5IDIySDE1QzIwIDIyIDIyIDIwIDIyIDE1VjEzXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3ZnPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+RXhwb3J0IENoYXQ8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIGA7XG5cbiAgICAgICAgICAgICAgICAvLyBJbnNlcnQgaXQgaW50byB0aGUgaGVhZGVyXG4gICAgICAgICAgICAgICAgaGVhZGVyRGl2LnByZXBlbmQoZXhwb3J0QnV0dG9uKTtcblxuICAgICAgICAgICAgICAgIC8vIEFkZCB0aGUgY2xpY2sgZXZlbnQgbGlzdGVuZXJcbiAgICAgICAgICAgICAgICBleHBvcnRCdXR0b24uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsICgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJFeHRyYWN0aW5nIGNoYXQgZGF0YS4uLlwiKTtcblxuICAgICAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHRpdGxlID0gXCJcIjtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGFjdGl2ZUxpbmsgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICduYXZbYXJpYS1sYWJlbD1cIkNoYXQgaGlzdG9yeVwiXSBhW2RhdGEtYWN0aXZlXSdcbiAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoYWN0aXZlTGluaykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlID0gYWN0aXZlTGluay50ZXh0Q29udGVudD8udHJpbSgpIHx8IFwiXCI7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIEZpbmQgYWxsIGNvbnZlcnNhdGlvbiB0dXJuc1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdHVybnMgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICdbZGF0YS10ZXN0aWRePVwiY29udmVyc2F0aW9uLXR1cm5cIl0nXG4gICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgbWVzc2FnZXM6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByb2xlOiBzdHJpbmc7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udGVudDogc3RyaW5nO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGltYWdlcz86IHN0cmluZ1tdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF0dGFjaG1lbnRzPzoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lOiBzdHJpbmc7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVybDogc3RyaW5nO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiBzdHJpbmc7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVtdO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVtdID0gW107XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHR1cm5zLmZvckVhY2goKHR1cm4pID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpc1VzZXIgPSB0dXJuLnF1ZXJ5U2VsZWN0b3IoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICdbZGF0YS1tZXNzYWdlLWF1dGhvci1yb2xlPVwidXNlclwiXSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGlzQXNzaXN0YW50ID0gdHVybi5xdWVyeVNlbGVjdG9yKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnW2RhdGEtbWVzc2FnZS1hdXRob3Itcm9sZT1cImFzc2lzdGFudFwiXSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHJvbGUgPSBcInVua25vd25cIjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgY29udGVudCA9IFwiXCI7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGltYWdlczogc3RyaW5nW10gPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgYXR0YWNobWVudHM6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZTogc3RyaW5nO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cmw6IHN0cmluZztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogc3RyaW5nO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1bXSA9IFtdO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGlzVXNlcikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByb2xlID0gXCJ1c2VyXCI7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHVzZXJCdWJibGUgPSB0dXJuLnF1ZXJ5U2VsZWN0b3IoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIi51c2VyLW1lc3NhZ2UtYnViYmxlLWNvbG9yLCBbZGF0YS1tdWx0aWxpbmVdXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udGVudCA9IHVzZXJCdWJibGU/LnRleHRDb250ZW50Py50cmltKCkgfHwgXCJcIjtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBFeHRyYWN0IHVzZXItdXBsb2FkZWQgaW1hZ2VzXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHVwbG9hZGVkSW1hZ2VzID0gdHVybi5xdWVyeVNlbGVjdG9yQWxsKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ2ltZ1thbHQ9XCJVcGxvYWRlZCBpbWFnZVwiXSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXBsb2FkZWRJbWFnZXMuZm9yRWFjaCgoaW1nKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBzcmMgPSAoaW1nIGFzIEhUTUxJbWFnZUVsZW1lbnQpLnNyYztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChzcmMgJiYgIWltYWdlcy5pbmNsdWRlcyhzcmMpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaW1hZ2VzLnB1c2goc3JjKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gRXh0cmFjdCBQREYgYW5kIG90aGVyIGRvY3VtZW50IGF0dGFjaG1lbnRzXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGF0dGFjaG1lbnRMaW5rcyA9IHR1cm4ucXVlcnlTZWxlY3RvckFsbChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICdhW3RhcmdldD1cIl9ibGFua1wiXVtyZWw9XCJub3JlZmVycmVyXCJdJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdHRhY2htZW50TGlua3MuZm9yRWFjaCgobGluaykgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgbmFtZUVsID0gbGluay5xdWVyeVNlbGVjdG9yKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiLnRydW5jYXRlLmZvbnQtc2VtaWJvbGRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHR5cGVFbCA9IGxpbmsucXVlcnlTZWxlY3RvcihcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIi50ZXh0LXRva2VuLXRleHQtc2Vjb25kYXJ5LnRydW5jYXRlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChuYW1lRWwpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBmaWxlTmFtZSA9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWVFbC50ZXh0Q29udGVudD8udHJpbSgpIHx8XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiVW5rbm93blwiO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGZpbGVUeXBlID1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZUVsPy50ZXh0Q29udGVudD8udHJpbSgpIHx8XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiRmlsZVwiO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXR0YWNobWVudHMucHVzaCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU6IGZpbGVOYW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cmw6IFwiXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6IGZpbGVUeXBlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBBbHRlcm5hdGl2ZTogVHJ5IHRvIGV4dHJhY3QgZmlsZSBpbmZvIGZyb20gbmVhcmJ5IGVsZW1lbnRzXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGZpbGVDb250YWluZXJzID0gdHVybi5xdWVyeVNlbGVjdG9yQWxsKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ1tjbGFzcyo9XCJmaWxlXCJdLCBbY2xhc3MqPVwiZG9jdW1lbnRcIl0nXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpbGVDb250YWluZXJzLmZvckVhY2goKGNvbnRhaW5lcikgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3Qgc3ZnUGFyZW50ID1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250YWluZXIucXVlcnlTZWxlY3RvcihcInN2Z1wiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChzdmdQYXJlbnQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBwYXJlbnQgPSBjb250YWluZXIuY2xvc2VzdChcImFcIik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJlbnQgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyZW50Lmhhc0F0dHJpYnV0ZShcImhyZWZcIilcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaHJlZiA9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJlbnQuZ2V0QXR0cmlidXRlKFwiaHJlZlwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGhyZWYpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IG5hbWVFbCA9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udGFpbmVyLnF1ZXJ5U2VsZWN0b3IoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiLnRydW5jYXRlLmZvbnQtc2VtaWJvbGRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB0eXBlRWwgPVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRhaW5lci5xdWVyeVNlbGVjdG9yKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIi50ZXh0LXRva2VuLXRleHQtc2Vjb25kYXJ5LnRydW5jYXRlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZUVsICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIWF0dGFjaG1lbnRzLnNvbWUoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIChhKSA9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYS5uYW1lID09PVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZUVsLnRleHRDb250ZW50Py50cmltKClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdHRhY2htZW50cy5wdXNoKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZTpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWVFbC50ZXh0Q29udGVudD8udHJpbSgpIHx8XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIlVua25vd25cIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXJsOiBocmVmLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZUVsPy50ZXh0Q29udGVudD8udHJpbSgpIHx8XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIkZpbGVcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcm9sZSA9IFwiYXNzaXN0YW50XCI7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGFzc2lzdGFudENvbnRlbnQgPSB0dXJuLnF1ZXJ5U2VsZWN0b3IoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnW2RhdGEtbWVzc2FnZS1hdXRob3Itcm9sZT1cImFzc2lzdGFudFwiXSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBFeHRyYWN0IHRleHQgY29udGVudFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250ZW50ID1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFzc2lzdGFudENvbnRlbnQ/LmlubmVySFRNTD8udHJpbSgpIHx8IFwiXCI7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gRXh0cmFjdCBpbWFnZXMgZnJvbSBhc3Npc3RhbnQgbWVzc2FnZXMgKGdlbmVyYXRlZCBpbWFnZXMpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGltYWdlRWxlbWVudHMgPSB0dXJuLnF1ZXJ5U2VsZWN0b3JBbGwoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnaW1nW2FsdD1cIkdlbmVyYXRlZCBpbWFnZVwiXSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaW1hZ2VFbGVtZW50cy5mb3JFYWNoKChpbWcpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHNyYyA9IChpbWcgYXMgSFRNTEltYWdlRWxlbWVudCkuc3JjO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHNyYyAmJiAhaW1hZ2VzLmluY2x1ZGVzKHNyYykpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbWFnZXMucHVzaChzcmMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRlbnQgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaW1hZ2VzLmxlbmd0aCA+IDAgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXR0YWNobWVudHMubGVuZ3RoID4gMFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBtZXNzYWdlOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByb2xlOiBzdHJpbmc7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250ZW50OiBzdHJpbmc7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbWFnZXM/OiBzdHJpbmdbXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF0dGFjaG1lbnRzPzoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU6IHN0cmluZztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cmw6IHN0cmluZztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiBzdHJpbmc7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9W107XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByb2xlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udGVudCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoaW1hZ2VzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2UuaW1hZ2VzID0gaW1hZ2VzO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGF0dGFjaG1lbnRzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2UuYXR0YWNobWVudHMgPSBhdHRhY2htZW50cztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2VzLnB1c2gobWVzc2FnZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIEFsc28gY2hlY2sgZm9yIGFueSBvcGVuIGlmcmFtZXMgd2l0aCBQREYvZG9jdW1lbnQgY29udGVudFxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaWZyYW1lcyA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgJ2lmcmFtZVtzcmMqPVwiYmFja2VuZC1hcGkvZXN0dWFyeS9jb250ZW50XCJdJ1xuICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmcmFtZXMuZm9yRWFjaCgoaWZyYW1lKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3Qgc3JjID0gKGlmcmFtZSBhcyBIVE1MSUZyYW1lRWxlbWVudCkuc3JjO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHRpdGxlID0gKGlmcmFtZSBhcyBIVE1MSUZyYW1lRWxlbWVudCkudGl0bGU7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBUcnkgdG8gZmluZCBjb3JyZXNwb25kaW5nIG1lc3NhZ2UgYW5kIGFkZCBVUkxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodGl0bGUgJiYgc3JjKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGxhc3RVc2VyTWVzc2FnZSA9IG1lc3NhZ2VzXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuZmlsdGVyKChtKSA9PiBtLnJvbGUgPT09IFwidXNlclwiKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnBvcCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYXN0VXNlck1lc3NhZ2UgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhc3RVc2VyTWVzc2FnZS5hdHRhY2htZW50c1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGF0dGFjaG1lbnQgPVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhc3RVc2VyTWVzc2FnZS5hdHRhY2htZW50cy5maW5kKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoYSkgPT4gYS5uYW1lID09PSB0aXRsZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoYXR0YWNobWVudCAmJiAhYXR0YWNobWVudC51cmwpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdHRhY2htZW50LnVybCA9IHNyYztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBTYXZlIHRvIENocm9tZSBzdG9yYWdlIGFuZCBvcGVuIG9wdGlvbnMgcGFnZVxuICAgICAgICAgICAgICAgICAgICAgICAgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hhdERhdGE6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZXMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzb3VyY2U6IFwiY2hhdGdwdFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzYXZlZENoYXRJZDogbnVsbCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGRmU2V0dGluZ3M6IG51bGwsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNocm9tZS5ydW50aW1lLnNlbmRNZXNzYWdlKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFjdGlvbjogXCJvcGVuT3B0aW9uc1wiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJDaGF0IGRhdGEgc2F2ZWQ6XCIsIG1lc3NhZ2VzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGV4dHJhY3RpbmcgY2hhdCBkYXRhOlwiLCBlcnJvcik7XG4gICAgICAgICAgICAgICAgICAgICAgICBhbGVydChcIkVycm9yIGV4dHJhY3RpbmcgY2hhdCBkYXRhLiBQbGVhc2UgdHJ5IGFnYWluLlwiKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCLinIUgRXhwb3J0IENoYXQgYnV0dG9uIGluc2VydGVkIHN1Y2Nlc3NmdWxseVwiKTtcblxuICAgICAgICAgICAgICAgIC8vIFN0b3AgdGhlIGludGVydmFsIG9uY2UgYnV0dG9uIGlzIGluc2VydGVkXG4gICAgICAgICAgICAgICAgaWYgKGJ1dHRvbkNoZWNrSW50ZXJ2YWwpIHtcbiAgICAgICAgICAgICAgICAgICAgY2xlYXJJbnRlcnZhbChidXR0b25DaGVja0ludGVydmFsKTtcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uQ2hlY2tJbnRlcnZhbCA9IG51bGw7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gRnVuY3Rpb24gdG8gY2hlY2sgZm9yIFVSTCBjaGFuZ2VzIGFuZCBoYW5kbGUgbmF2aWdhdGlvblxuICAgICAgICBmdW5jdGlvbiBjaGVja1VybENoYW5nZSgpIHtcbiAgICAgICAgICAgIGlmIChsb2NhdGlvbi5ocmVmICE9PSBjdXJyZW50VXJsKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXG4gICAgICAgICAgICAgICAgICAgIFwiVVJMIGNoYW5nZWQgZnJvbVwiLFxuICAgICAgICAgICAgICAgICAgICBjdXJyZW50VXJsLFxuICAgICAgICAgICAgICAgICAgICBcInRvXCIsXG4gICAgICAgICAgICAgICAgICAgIGxvY2F0aW9uLmhyZWZcbiAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgIGN1cnJlbnRVcmwgPSBsb2NhdGlvbi5ocmVmO1xuXG4gICAgICAgICAgICAgICAgLy8gQ2xlYXIgYW55IGV4aXN0aW5nIGJ1dHRvbiB3aGVuIG5hdmlnYXRpbmcgYXdheSBmcm9tIGNoYXQgcGFnZVxuICAgICAgICAgICAgICAgIGNvbnN0IGV4aXN0aW5nQnV0dG9uID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcbiAgICAgICAgICAgICAgICAgICAgXCIjZXhwb3J0LWNoYXQtYnV0dG9uXCJcbiAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgIGlmIChleGlzdGluZ0J1dHRvbiAmJiAhaXNPbkNoYXRQYWdlKCkpIHtcbiAgICAgICAgICAgICAgICAgICAgZXhpc3RpbmdCdXR0b24ucmVtb3ZlKCk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiUmVtb3ZlZCBidXR0b24gLSBub3Qgb24gY2hhdCBwYWdlXCIpO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIC8vIElmIG5hdmlnYXRpbmcgdG8gYSBjaGF0IHBhZ2UsIHN0YXJ0IGxvb2tpbmcgZm9yIHRoZSBoZWFkZXJcbiAgICAgICAgICAgICAgICBpZiAoaXNPbkNoYXRQYWdlKCkpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXG4gICAgICAgICAgICAgICAgICAgICAgICBcIk5hdmlnYXRlZCB0byBjaGF0IHBhZ2UsIHdhaXRpbmcgZm9yIGhlYWRlci4uLlwiXG4gICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgIC8vIFN0YXJ0IGNoZWNraW5nIGZvciB0aGUgaGVhZGVyIGVsZW1lbnRcbiAgICAgICAgICAgICAgICAgICAgaWYgKGJ1dHRvbkNoZWNrSW50ZXJ2YWwpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsZWFySW50ZXJ2YWwoYnV0dG9uQ2hlY2tJbnRlcnZhbCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uQ2hlY2tJbnRlcnZhbCA9IHdpbmRvdy5zZXRJbnRlcnZhbCgoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpbnNlcnRFeHBvcnRCdXR0b24oKTtcbiAgICAgICAgICAgICAgICAgICAgfSwgMzAwKTtcblxuICAgICAgICAgICAgICAgICAgICAvLyBTdG9wIGNoZWNraW5nIGFmdGVyIDE1IHNlY29uZHNcbiAgICAgICAgICAgICAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoYnV0dG9uQ2hlY2tJbnRlcnZhbCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsZWFySW50ZXJ2YWwoYnV0dG9uQ2hlY2tJbnRlcnZhbCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnV0dG9uQ2hlY2tJbnRlcnZhbCA9IG51bGw7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH0sIDE1MDAwKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAvLyBJbml0aWFsIGluc2VydGlvbiBhdHRlbXB0IGlmIGFscmVhZHkgb24gYSBjaGF0IHBhZ2VcbiAgICAgICAgaWYgKGlzT25DaGF0UGFnZSgpKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkFscmVhZHkgb24gY2hhdCBwYWdlLCBzdGFydGluZyBidXR0b24gaW5zZXJ0aW9uLi4uXCIpO1xuICAgICAgICAgICAgYnV0dG9uQ2hlY2tJbnRlcnZhbCA9IHdpbmRvdy5zZXRJbnRlcnZhbCgoKSA9PiB7XG4gICAgICAgICAgICAgICAgaW5zZXJ0RXhwb3J0QnV0dG9uKCk7XG4gICAgICAgICAgICB9LCAzMDApO1xuXG4gICAgICAgICAgICAvLyBTdG9wIGNoZWNraW5nIGFmdGVyIDE1IHNlY29uZHNcbiAgICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChidXR0b25DaGVja0ludGVydmFsKSB7XG4gICAgICAgICAgICAgICAgICAgIGNsZWFySW50ZXJ2YWwoYnV0dG9uQ2hlY2tJbnRlcnZhbCk7XG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbkNoZWNrSW50ZXJ2YWwgPSBudWxsO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0sIDE1MDAwKTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIFNldCB1cCBNdXRhdGlvbk9ic2VydmVyIHRvIHdhdGNoIGZvciBET00gY2hhbmdlc1xuICAgICAgICBjb25zdCBvYnNlcnZlciA9IG5ldyBNdXRhdGlvbk9ic2VydmVyKCgpID0+IHtcbiAgICAgICAgICAgIGNoZWNrVXJsQ2hhbmdlKCk7XG5cbiAgICAgICAgICAgIC8vIFRyeSB0byBpbnNlcnQgYnV0dG9uIGlmIHdlJ3JlIG9uIGEgY2hhdCBwYWdlIGFuZCBpdCdzIG1pc3NpbmdcbiAgICAgICAgICAgIGlmIChcbiAgICAgICAgICAgICAgICBpc09uQ2hhdFBhZ2UoKSAmJlxuICAgICAgICAgICAgICAgICFkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiI2V4cG9ydC1jaGF0LWJ1dHRvblwiKVxuICAgICAgICAgICAgKSB7XG4gICAgICAgICAgICAgICAgaW5zZXJ0RXhwb3J0QnV0dG9uKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuXG4gICAgICAgIC8vIFN0YXJ0IG9ic2VydmluZyB0aGUgZG9jdW1lbnQgYm9keSBmb3IgY2hhbmdlc1xuICAgICAgICBvYnNlcnZlci5vYnNlcnZlKGRvY3VtZW50LmJvZHksIHtcbiAgICAgICAgICAgIGNoaWxkTGlzdDogdHJ1ZSxcbiAgICAgICAgICAgIHN1YnRyZWU6IHRydWUsXG4gICAgICAgIH0pO1xuXG4gICAgICAgIC8vIFBlcmlvZGljIFVSTCBjaGVjayBhcyBmYWxsYmFja1xuICAgICAgICBzZXRJbnRlcnZhbChjaGVja1VybENoYW5nZSwgMTAwMCk7XG5cbiAgICAgICAgY29uc29sZS5sb2coXCLinIUgQ29udGVudCBzY3JpcHQgaW5pdGlhbGl6ZWQgLSB3YXRjaGluZyBmb3IgY2hhdCBwYWdlc1wiKTtcbiAgICB9LFxufSk7XG4iLCIvLyAjcmVnaW9uIHNuaXBwZXRcbmV4cG9ydCBjb25zdCBicm93c2VyID0gZ2xvYmFsVGhpcy5icm93c2VyPy5ydW50aW1lPy5pZFxuICA/IGdsb2JhbFRoaXMuYnJvd3NlclxuICA6IGdsb2JhbFRoaXMuY2hyb21lO1xuLy8gI2VuZHJlZ2lvbiBzbmlwcGV0XG4iLCJpbXBvcnQgeyBicm93c2VyIGFzIF9icm93c2VyIH0gZnJvbSBcIkB3eHQtZGV2L2Jyb3dzZXJcIjtcbmV4cG9ydCBjb25zdCBicm93c2VyID0gX2Jyb3dzZXI7XG5leHBvcnQge307XG4iLCJmdW5jdGlvbiBwcmludChtZXRob2QsIC4uLmFyZ3MpIHtcbiAgaWYgKGltcG9ydC5tZXRhLmVudi5NT0RFID09PSBcInByb2R1Y3Rpb25cIikgcmV0dXJuO1xuICBpZiAodHlwZW9mIGFyZ3NbMF0gPT09IFwic3RyaW5nXCIpIHtcbiAgICBjb25zdCBtZXNzYWdlID0gYXJncy5zaGlmdCgpO1xuICAgIG1ldGhvZChgW3d4dF0gJHttZXNzYWdlfWAsIC4uLmFyZ3MpO1xuICB9IGVsc2Uge1xuICAgIG1ldGhvZChcIlt3eHRdXCIsIC4uLmFyZ3MpO1xuICB9XG59XG5leHBvcnQgY29uc3QgbG9nZ2VyID0ge1xuICBkZWJ1ZzogKC4uLmFyZ3MpID0+IHByaW50KGNvbnNvbGUuZGVidWcsIC4uLmFyZ3MpLFxuICBsb2c6ICguLi5hcmdzKSA9PiBwcmludChjb25zb2xlLmxvZywgLi4uYXJncyksXG4gIHdhcm46ICguLi5hcmdzKSA9PiBwcmludChjb25zb2xlLndhcm4sIC4uLmFyZ3MpLFxuICBlcnJvcjogKC4uLmFyZ3MpID0+IHByaW50KGNvbnNvbGUuZXJyb3IsIC4uLmFyZ3MpXG59O1xuIiwiaW1wb3J0IHsgYnJvd3NlciB9IGZyb20gXCJ3eHQvYnJvd3NlclwiO1xuZXhwb3J0IGNsYXNzIFd4dExvY2F0aW9uQ2hhbmdlRXZlbnQgZXh0ZW5kcyBFdmVudCB7XG4gIGNvbnN0cnVjdG9yKG5ld1VybCwgb2xkVXJsKSB7XG4gICAgc3VwZXIoV3h0TG9jYXRpb25DaGFuZ2VFdmVudC5FVkVOVF9OQU1FLCB7fSk7XG4gICAgdGhpcy5uZXdVcmwgPSBuZXdVcmw7XG4gICAgdGhpcy5vbGRVcmwgPSBvbGRVcmw7XG4gIH1cbiAgc3RhdGljIEVWRU5UX05BTUUgPSBnZXRVbmlxdWVFdmVudE5hbWUoXCJ3eHQ6bG9jYXRpb25jaGFuZ2VcIik7XG59XG5leHBvcnQgZnVuY3Rpb24gZ2V0VW5pcXVlRXZlbnROYW1lKGV2ZW50TmFtZSkge1xuICByZXR1cm4gYCR7YnJvd3Nlcj8ucnVudGltZT8uaWR9OiR7aW1wb3J0Lm1ldGEuZW52LkVOVFJZUE9JTlR9OiR7ZXZlbnROYW1lfWA7XG59XG4iLCJpbXBvcnQgeyBXeHRMb2NhdGlvbkNoYW5nZUV2ZW50IH0gZnJvbSBcIi4vY3VzdG9tLWV2ZW50cy5tanNcIjtcbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVMb2NhdGlvbldhdGNoZXIoY3R4KSB7XG4gIGxldCBpbnRlcnZhbDtcbiAgbGV0IG9sZFVybDtcbiAgcmV0dXJuIHtcbiAgICAvKipcbiAgICAgKiBFbnN1cmUgdGhlIGxvY2F0aW9uIHdhdGNoZXIgaXMgYWN0aXZlbHkgbG9va2luZyBmb3IgVVJMIGNoYW5nZXMuIElmIGl0J3MgYWxyZWFkeSB3YXRjaGluZyxcbiAgICAgKiB0aGlzIGlzIGEgbm9vcC5cbiAgICAgKi9cbiAgICBydW4oKSB7XG4gICAgICBpZiAoaW50ZXJ2YWwgIT0gbnVsbCkgcmV0dXJuO1xuICAgICAgb2xkVXJsID0gbmV3IFVSTChsb2NhdGlvbi5ocmVmKTtcbiAgICAgIGludGVydmFsID0gY3R4LnNldEludGVydmFsKCgpID0+IHtcbiAgICAgICAgbGV0IG5ld1VybCA9IG5ldyBVUkwobG9jYXRpb24uaHJlZik7XG4gICAgICAgIGlmIChuZXdVcmwuaHJlZiAhPT0gb2xkVXJsLmhyZWYpIHtcbiAgICAgICAgICB3aW5kb3cuZGlzcGF0Y2hFdmVudChuZXcgV3h0TG9jYXRpb25DaGFuZ2VFdmVudChuZXdVcmwsIG9sZFVybCkpO1xuICAgICAgICAgIG9sZFVybCA9IG5ld1VybDtcbiAgICAgICAgfVxuICAgICAgfSwgMWUzKTtcbiAgICB9XG4gIH07XG59XG4iLCJpbXBvcnQgeyBicm93c2VyIH0gZnJvbSBcInd4dC9icm93c2VyXCI7XG5pbXBvcnQgeyBsb2dnZXIgfSBmcm9tIFwiLi4vdXRpbHMvaW50ZXJuYWwvbG9nZ2VyLm1qc1wiO1xuaW1wb3J0IHtcbiAgZ2V0VW5pcXVlRXZlbnROYW1lXG59IGZyb20gXCIuL2ludGVybmFsL2N1c3RvbS1ldmVudHMubWpzXCI7XG5pbXBvcnQgeyBjcmVhdGVMb2NhdGlvbldhdGNoZXIgfSBmcm9tIFwiLi9pbnRlcm5hbC9sb2NhdGlvbi13YXRjaGVyLm1qc1wiO1xuZXhwb3J0IGNsYXNzIENvbnRlbnRTY3JpcHRDb250ZXh0IHtcbiAgY29uc3RydWN0b3IoY29udGVudFNjcmlwdE5hbWUsIG9wdGlvbnMpIHtcbiAgICB0aGlzLmNvbnRlbnRTY3JpcHROYW1lID0gY29udGVudFNjcmlwdE5hbWU7XG4gICAgdGhpcy5vcHRpb25zID0gb3B0aW9ucztcbiAgICB0aGlzLmFib3J0Q29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcbiAgICBpZiAodGhpcy5pc1RvcEZyYW1lKSB7XG4gICAgICB0aGlzLmxpc3RlbkZvck5ld2VyU2NyaXB0cyh7IGlnbm9yZUZpcnN0RXZlbnQ6IHRydWUgfSk7XG4gICAgICB0aGlzLnN0b3BPbGRTY3JpcHRzKCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMubGlzdGVuRm9yTmV3ZXJTY3JpcHRzKCk7XG4gICAgfVxuICB9XG4gIHN0YXRpYyBTQ1JJUFRfU1RBUlRFRF9NRVNTQUdFX1RZUEUgPSBnZXRVbmlxdWVFdmVudE5hbWUoXG4gICAgXCJ3eHQ6Y29udGVudC1zY3JpcHQtc3RhcnRlZFwiXG4gICk7XG4gIGlzVG9wRnJhbWUgPSB3aW5kb3cuc2VsZiA9PT0gd2luZG93LnRvcDtcbiAgYWJvcnRDb250cm9sbGVyO1xuICBsb2NhdGlvbldhdGNoZXIgPSBjcmVhdGVMb2NhdGlvbldhdGNoZXIodGhpcyk7XG4gIHJlY2VpdmVkTWVzc2FnZUlkcyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG4gIGdldCBzaWduYWwoKSB7XG4gICAgcmV0dXJuIHRoaXMuYWJvcnRDb250cm9sbGVyLnNpZ25hbDtcbiAgfVxuICBhYm9ydChyZWFzb24pIHtcbiAgICByZXR1cm4gdGhpcy5hYm9ydENvbnRyb2xsZXIuYWJvcnQocmVhc29uKTtcbiAgfVxuICBnZXQgaXNJbnZhbGlkKCkge1xuICAgIGlmIChicm93c2VyLnJ1bnRpbWUuaWQgPT0gbnVsbCkge1xuICAgICAgdGhpcy5ub3RpZnlJbnZhbGlkYXRlZCgpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5zaWduYWwuYWJvcnRlZDtcbiAgfVxuICBnZXQgaXNWYWxpZCgpIHtcbiAgICByZXR1cm4gIXRoaXMuaXNJbnZhbGlkO1xuICB9XG4gIC8qKlxuICAgKiBBZGQgYSBsaXN0ZW5lciB0aGF0IGlzIGNhbGxlZCB3aGVuIHRoZSBjb250ZW50IHNjcmlwdCdzIGNvbnRleHQgaXMgaW52YWxpZGF0ZWQuXG4gICAqXG4gICAqIEByZXR1cm5zIEEgZnVuY3Rpb24gdG8gcmVtb3ZlIHRoZSBsaXN0ZW5lci5cbiAgICpcbiAgICogQGV4YW1wbGVcbiAgICogYnJvd3Nlci5ydW50aW1lLm9uTWVzc2FnZS5hZGRMaXN0ZW5lcihjYik7XG4gICAqIGNvbnN0IHJlbW92ZUludmFsaWRhdGVkTGlzdGVuZXIgPSBjdHgub25JbnZhbGlkYXRlZCgoKSA9PiB7XG4gICAqICAgYnJvd3Nlci5ydW50aW1lLm9uTWVzc2FnZS5yZW1vdmVMaXN0ZW5lcihjYik7XG4gICAqIH0pXG4gICAqIC8vIC4uLlxuICAgKiByZW1vdmVJbnZhbGlkYXRlZExpc3RlbmVyKCk7XG4gICAqL1xuICBvbkludmFsaWRhdGVkKGNiKSB7XG4gICAgdGhpcy5zaWduYWwuYWRkRXZlbnRMaXN0ZW5lcihcImFib3J0XCIsIGNiKTtcbiAgICByZXR1cm4gKCkgPT4gdGhpcy5zaWduYWwucmVtb3ZlRXZlbnRMaXN0ZW5lcihcImFib3J0XCIsIGNiKTtcbiAgfVxuICAvKipcbiAgICogUmV0dXJuIGEgcHJvbWlzZSB0aGF0IG5ldmVyIHJlc29sdmVzLiBVc2VmdWwgaWYgeW91IGhhdmUgYW4gYXN5bmMgZnVuY3Rpb24gdGhhdCBzaG91bGRuJ3QgcnVuXG4gICAqIGFmdGVyIHRoZSBjb250ZXh0IGlzIGV4cGlyZWQuXG4gICAqXG4gICAqIEBleGFtcGxlXG4gICAqIGNvbnN0IGdldFZhbHVlRnJvbVN0b3JhZ2UgPSBhc3luYyAoKSA9PiB7XG4gICAqICAgaWYgKGN0eC5pc0ludmFsaWQpIHJldHVybiBjdHguYmxvY2soKTtcbiAgICpcbiAgICogICAvLyAuLi5cbiAgICogfVxuICAgKi9cbiAgYmxvY2soKSB7XG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKCgpID0+IHtcbiAgICB9KTtcbiAgfVxuICAvKipcbiAgICogV3JhcHBlciBhcm91bmQgYHdpbmRvdy5zZXRJbnRlcnZhbGAgdGhhdCBhdXRvbWF0aWNhbGx5IGNsZWFycyB0aGUgaW50ZXJ2YWwgd2hlbiBpbnZhbGlkYXRlZC5cbiAgICpcbiAgICogSW50ZXJ2YWxzIGNhbiBiZSBjbGVhcmVkIGJ5IGNhbGxpbmcgdGhlIG5vcm1hbCBgY2xlYXJJbnRlcnZhbGAgZnVuY3Rpb24uXG4gICAqL1xuICBzZXRJbnRlcnZhbChoYW5kbGVyLCB0aW1lb3V0KSB7XG4gICAgY29uc3QgaWQgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XG4gICAgICBpZiAodGhpcy5pc1ZhbGlkKSBoYW5kbGVyKCk7XG4gICAgfSwgdGltZW91dCk7XG4gICAgdGhpcy5vbkludmFsaWRhdGVkKCgpID0+IGNsZWFySW50ZXJ2YWwoaWQpKTtcbiAgICByZXR1cm4gaWQ7XG4gIH1cbiAgLyoqXG4gICAqIFdyYXBwZXIgYXJvdW5kIGB3aW5kb3cuc2V0VGltZW91dGAgdGhhdCBhdXRvbWF0aWNhbGx5IGNsZWFycyB0aGUgaW50ZXJ2YWwgd2hlbiBpbnZhbGlkYXRlZC5cbiAgICpcbiAgICogVGltZW91dHMgY2FuIGJlIGNsZWFyZWQgYnkgY2FsbGluZyB0aGUgbm9ybWFsIGBzZXRUaW1lb3V0YCBmdW5jdGlvbi5cbiAgICovXG4gIHNldFRpbWVvdXQoaGFuZGxlciwgdGltZW91dCkge1xuICAgIGNvbnN0IGlkID0gc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICBpZiAodGhpcy5pc1ZhbGlkKSBoYW5kbGVyKCk7XG4gICAgfSwgdGltZW91dCk7XG4gICAgdGhpcy5vbkludmFsaWRhdGVkKCgpID0+IGNsZWFyVGltZW91dChpZCkpO1xuICAgIHJldHVybiBpZDtcbiAgfVxuICAvKipcbiAgICogV3JhcHBlciBhcm91bmQgYHdpbmRvdy5yZXF1ZXN0QW5pbWF0aW9uRnJhbWVgIHRoYXQgYXV0b21hdGljYWxseSBjYW5jZWxzIHRoZSByZXF1ZXN0IHdoZW5cbiAgICogaW52YWxpZGF0ZWQuXG4gICAqXG4gICAqIENhbGxiYWNrcyBjYW4gYmUgY2FuY2VsZWQgYnkgY2FsbGluZyB0aGUgbm9ybWFsIGBjYW5jZWxBbmltYXRpb25GcmFtZWAgZnVuY3Rpb24uXG4gICAqL1xuICByZXF1ZXN0QW5pbWF0aW9uRnJhbWUoY2FsbGJhY2spIHtcbiAgICBjb25zdCBpZCA9IHJlcXVlc3RBbmltYXRpb25GcmFtZSgoLi4uYXJncykgPT4ge1xuICAgICAgaWYgKHRoaXMuaXNWYWxpZCkgY2FsbGJhY2soLi4uYXJncyk7XG4gICAgfSk7XG4gICAgdGhpcy5vbkludmFsaWRhdGVkKCgpID0+IGNhbmNlbEFuaW1hdGlvbkZyYW1lKGlkKSk7XG4gICAgcmV0dXJuIGlkO1xuICB9XG4gIC8qKlxuICAgKiBXcmFwcGVyIGFyb3VuZCBgd2luZG93LnJlcXVlc3RJZGxlQ2FsbGJhY2tgIHRoYXQgYXV0b21hdGljYWxseSBjYW5jZWxzIHRoZSByZXF1ZXN0IHdoZW5cbiAgICogaW52YWxpZGF0ZWQuXG4gICAqXG4gICAqIENhbGxiYWNrcyBjYW4gYmUgY2FuY2VsZWQgYnkgY2FsbGluZyB0aGUgbm9ybWFsIGBjYW5jZWxJZGxlQ2FsbGJhY2tgIGZ1bmN0aW9uLlxuICAgKi9cbiAgcmVxdWVzdElkbGVDYWxsYmFjayhjYWxsYmFjaywgb3B0aW9ucykge1xuICAgIGNvbnN0IGlkID0gcmVxdWVzdElkbGVDYWxsYmFjaygoLi4uYXJncykgPT4ge1xuICAgICAgaWYgKCF0aGlzLnNpZ25hbC5hYm9ydGVkKSBjYWxsYmFjayguLi5hcmdzKTtcbiAgICB9LCBvcHRpb25zKTtcbiAgICB0aGlzLm9uSW52YWxpZGF0ZWQoKCkgPT4gY2FuY2VsSWRsZUNhbGxiYWNrKGlkKSk7XG4gICAgcmV0dXJuIGlkO1xuICB9XG4gIGFkZEV2ZW50TGlzdGVuZXIodGFyZ2V0LCB0eXBlLCBoYW5kbGVyLCBvcHRpb25zKSB7XG4gICAgaWYgKHR5cGUgPT09IFwid3h0OmxvY2F0aW9uY2hhbmdlXCIpIHtcbiAgICAgIGlmICh0aGlzLmlzVmFsaWQpIHRoaXMubG9jYXRpb25XYXRjaGVyLnJ1bigpO1xuICAgIH1cbiAgICB0YXJnZXQuYWRkRXZlbnRMaXN0ZW5lcj8uKFxuICAgICAgdHlwZS5zdGFydHNXaXRoKFwid3h0OlwiKSA/IGdldFVuaXF1ZUV2ZW50TmFtZSh0eXBlKSA6IHR5cGUsXG4gICAgICBoYW5kbGVyLFxuICAgICAge1xuICAgICAgICAuLi5vcHRpb25zLFxuICAgICAgICBzaWduYWw6IHRoaXMuc2lnbmFsXG4gICAgICB9XG4gICAgKTtcbiAgfVxuICAvKipcbiAgICogQGludGVybmFsXG4gICAqIEFib3J0IHRoZSBhYm9ydCBjb250cm9sbGVyIGFuZCBleGVjdXRlIGFsbCBgb25JbnZhbGlkYXRlZGAgbGlzdGVuZXJzLlxuICAgKi9cbiAgbm90aWZ5SW52YWxpZGF0ZWQoKSB7XG4gICAgdGhpcy5hYm9ydChcIkNvbnRlbnQgc2NyaXB0IGNvbnRleHQgaW52YWxpZGF0ZWRcIik7XG4gICAgbG9nZ2VyLmRlYnVnKFxuICAgICAgYENvbnRlbnQgc2NyaXB0IFwiJHt0aGlzLmNvbnRlbnRTY3JpcHROYW1lfVwiIGNvbnRleHQgaW52YWxpZGF0ZWRgXG4gICAgKTtcbiAgfVxuICBzdG9wT2xkU2NyaXB0cygpIHtcbiAgICB3aW5kb3cucG9zdE1lc3NhZ2UoXG4gICAgICB7XG4gICAgICAgIHR5cGU6IENvbnRlbnRTY3JpcHRDb250ZXh0LlNDUklQVF9TVEFSVEVEX01FU1NBR0VfVFlQRSxcbiAgICAgICAgY29udGVudFNjcmlwdE5hbWU6IHRoaXMuY29udGVudFNjcmlwdE5hbWUsXG4gICAgICAgIG1lc3NhZ2VJZDogTWF0aC5yYW5kb20oKS50b1N0cmluZygzNikuc2xpY2UoMilcbiAgICAgIH0sXG4gICAgICBcIipcIlxuICAgICk7XG4gIH1cbiAgdmVyaWZ5U2NyaXB0U3RhcnRlZEV2ZW50KGV2ZW50KSB7XG4gICAgY29uc3QgaXNTY3JpcHRTdGFydGVkRXZlbnQgPSBldmVudC5kYXRhPy50eXBlID09PSBDb250ZW50U2NyaXB0Q29udGV4dC5TQ1JJUFRfU1RBUlRFRF9NRVNTQUdFX1RZUEU7XG4gICAgY29uc3QgaXNTYW1lQ29udGVudFNjcmlwdCA9IGV2ZW50LmRhdGE/LmNvbnRlbnRTY3JpcHROYW1lID09PSB0aGlzLmNvbnRlbnRTY3JpcHROYW1lO1xuICAgIGNvbnN0IGlzTm90RHVwbGljYXRlID0gIXRoaXMucmVjZWl2ZWRNZXNzYWdlSWRzLmhhcyhldmVudC5kYXRhPy5tZXNzYWdlSWQpO1xuICAgIHJldHVybiBpc1NjcmlwdFN0YXJ0ZWRFdmVudCAmJiBpc1NhbWVDb250ZW50U2NyaXB0ICYmIGlzTm90RHVwbGljYXRlO1xuICB9XG4gIGxpc3RlbkZvck5ld2VyU2NyaXB0cyhvcHRpb25zKSB7XG4gICAgbGV0IGlzRmlyc3QgPSB0cnVlO1xuICAgIGNvbnN0IGNiID0gKGV2ZW50KSA9PiB7XG4gICAgICBpZiAodGhpcy52ZXJpZnlTY3JpcHRTdGFydGVkRXZlbnQoZXZlbnQpKSB7XG4gICAgICAgIHRoaXMucmVjZWl2ZWRNZXNzYWdlSWRzLmFkZChldmVudC5kYXRhLm1lc3NhZ2VJZCk7XG4gICAgICAgIGNvbnN0IHdhc0ZpcnN0ID0gaXNGaXJzdDtcbiAgICAgICAgaXNGaXJzdCA9IGZhbHNlO1xuICAgICAgICBpZiAod2FzRmlyc3QgJiYgb3B0aW9ucz8uaWdub3JlRmlyc3RFdmVudCkgcmV0dXJuO1xuICAgICAgICB0aGlzLm5vdGlmeUludmFsaWRhdGVkKCk7XG4gICAgICB9XG4gICAgfTtcbiAgICBhZGRFdmVudExpc3RlbmVyKFwibWVzc2FnZVwiLCBjYik7XG4gICAgdGhpcy5vbkludmFsaWRhdGVkKCgpID0+IHJlbW92ZUV2ZW50TGlzdGVuZXIoXCJtZXNzYWdlXCIsIGNiKSk7XG4gIH1cbn1cbiJdLCJuYW1lcyI6WyJkZWZpbml0aW9uIiwiY29udGVudCIsImJyb3dzZXIiLCJfYnJvd3NlciIsInByaW50IiwibG9nZ2VyIl0sIm1hcHBpbmdzIjoiOztBQUFPLFdBQVMsb0JBQW9CQSxhQUFZO0FBQzlDLFdBQU9BO0FBQUEsRUFDVDtBQ0ZBLFFBQUEsYUFBQSxvQkFBQTtBQUFBLElBQW1DLFNBQUEsQ0FBQSx5QkFBQSwyQkFBQTtBQUFBLElBQytCLE9BQUE7QUFFMUQsVUFBQSxhQUFBLFNBQUE7QUFDQSxVQUFBLHNCQUFBO0FBR0EsZUFBQSxlQUFBO0FBQ0ksZUFBQSxTQUFBLEtBQUEsU0FBQSxLQUFBLEtBQUEsU0FBQSxLQUFBLFNBQUEsS0FBQTtBQUFBLE1BQ2lFO0FBS3JFLGVBQUEscUJBQUE7QUFFSSxZQUFBLENBQUEsYUFBQSxHQUFBO0FBQ0ksa0JBQUEsSUFBQSwrQ0FBQTtBQUNBO0FBQUEsUUFBQTtBQUdKLGNBQUEsWUFBQSxTQUFBO0FBQUEsVUFBMkI7QUFBQSxRQUN2QjtBQUlKLFlBQUEsYUFBQSxDQUFBLFNBQUEsY0FBQSxxQkFBQSxHQUFBO0FBRUksZ0JBQUEsZUFBQSxTQUFBLGNBQUEsUUFBQTtBQUNBLHVCQUFBLEtBQUE7QUFDQSx1QkFBQSxZQUFBO0FBRUEsdUJBQUEsYUFBQSxjQUFBLGFBQUE7QUFHQSx1QkFBQSxZQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBZUEsb0JBQUEsUUFBQSxZQUFBO0FBR0EsdUJBQUEsaUJBQUEsU0FBQSxNQUFBO0FBQ0ksb0JBQUEsSUFBQSx5QkFBQTtBQUVBLGdCQUFBO0FBQ0ksa0JBQUEsUUFBQTtBQUNBLG9CQUFBLGFBQUEsU0FBQTtBQUFBLGdCQUE0QjtBQUFBLGNBQ3hCO0FBRUosa0JBQUEsWUFBQTtBQUNJLHdCQUFBLFdBQUEsYUFBQSxLQUFBLEtBQUE7QUFBQSxjQUEwQztBQUk5QyxvQkFBQSxRQUFBLFNBQUE7QUFBQSxnQkFBdUI7QUFBQSxjQUNuQjtBQUVKLG9CQUFBLFdBQUEsQ0FBQTtBQVdBLG9CQUFBLFFBQUEsQ0FBQSxTQUFBO0FBQ0ksc0JBQUEsU0FBQSxLQUFBO0FBQUEsa0JBQW9CO0FBQUEsZ0JBQ2hCO0FBRUosc0JBQUEsY0FBQSxLQUFBO0FBQUEsa0JBQXlCO0FBQUEsZ0JBQ3JCO0FBR0osb0JBQUEsT0FBQTtBQUNBLG9CQUFBQyxXQUFBO0FBQ0Esb0JBQUEsU0FBQSxDQUFBO0FBQ0Esb0JBQUEsY0FBQSxDQUFBO0FBTUEsb0JBQUEsUUFBQTtBQUNJLHlCQUFBO0FBQ0Esd0JBQUEsYUFBQSxLQUFBO0FBQUEsb0JBQXdCO0FBQUEsa0JBQ3BCO0FBRUosa0JBQUFBLFdBQUEsWUFBQSxhQUFBLEtBQUEsS0FBQTtBQUdBLHdCQUFBLGlCQUFBLEtBQUE7QUFBQSxvQkFBNEI7QUFBQSxrQkFDeEI7QUFFSixpQ0FBQSxRQUFBLENBQUEsUUFBQTtBQUNJLDBCQUFBLE1BQUEsSUFBQTtBQUNBLHdCQUFBLE9BQUEsQ0FBQSxPQUFBLFNBQUEsR0FBQSxHQUFBO0FBQ0ksNkJBQUEsS0FBQSxHQUFBO0FBQUEsb0JBQWU7QUFBQSxrQkFDbkIsQ0FBQTtBQUlKLHdCQUFBLGtCQUFBLEtBQUE7QUFBQSxvQkFBNkI7QUFBQSxrQkFDekI7QUFFSixrQ0FBQSxRQUFBLENBQUEsU0FBQTtBQUNJLDBCQUFBLFNBQUEsS0FBQTtBQUFBLHNCQUFvQjtBQUFBLG9CQUNoQjtBQUVKLDBCQUFBLFNBQUEsS0FBQTtBQUFBLHNCQUFvQjtBQUFBLG9CQUNoQjtBQUdKLHdCQUFBLFFBQUE7QUFDSSw0QkFBQSxXQUFBLE9BQUEsYUFBQSxLQUFBLEtBQUE7QUFHQSw0QkFBQSxXQUFBLFFBQUEsYUFBQSxLQUFBLEtBQUE7QUFJQSxrQ0FBQSxLQUFBO0FBQUEsd0JBQWlCLE1BQUE7QUFBQSx3QkFDUCxLQUFBO0FBQUEsd0JBQ0QsTUFBQTtBQUFBLHNCQUNDLENBQUE7QUFBQSxvQkFDVDtBQUFBLGtCQUNMLENBQUE7QUFJSix3QkFBQSxpQkFBQSxLQUFBO0FBQUEsb0JBQTRCO0FBQUEsa0JBQ3hCO0FBRUosaUNBQUEsUUFBQSxDQUFBLGNBQUE7QUFDSSwwQkFBQSxZQUFBLFVBQUEsY0FBQSxLQUFBO0FBRUEsd0JBQUEsV0FBQTtBQUNJLDRCQUFBLFNBQUEsVUFBQSxRQUFBLEdBQUE7QUFDQSwwQkFBQSxVQUFBLE9BQUEsYUFBQSxNQUFBLEdBQUE7QUFJSSw4QkFBQSxPQUFBLE9BQUEsYUFBQSxNQUFBO0FBRUEsNEJBQUEsTUFBQTtBQUNJLGdDQUFBLFNBQUEsVUFBQTtBQUFBLDRCQUNjO0FBQUEsMEJBQ047QUFFUixnQ0FBQSxTQUFBLFVBQUE7QUFBQSw0QkFDYztBQUFBLDBCQUNOO0FBR1IsOEJBQUEsVUFBQSxDQUFBLFlBQUE7QUFBQSw0QkFFaUIsQ0FBQSxNQUFBLEVBQUEsU0FBQSxPQUFBLGFBQUEsS0FBQTtBQUFBLDBCQUdvQixHQUFBO0FBR2pDLHdDQUFBLEtBQUE7QUFBQSw4QkFBaUIsTUFBQSxPQUFBLGFBQUEsS0FBQSxLQUFBO0FBQUEsOEJBR1QsS0FBQTtBQUFBLDhCQUNDLE1BQUEsUUFBQSxhQUFBLFVBQUE7QUFBQSw0QkFHRCxDQUFBO0FBQUEsMEJBQ1A7QUFBQSx3QkFDTDtBQUFBLHNCQUNKO0FBQUEsb0JBQ0o7QUFBQSxrQkFDSixDQUFBO0FBQUEsZ0JBQ0gsT0FBQTtBQUVELHlCQUFBO0FBQ0Esd0JBQUEsbUJBQUEsS0FBQTtBQUFBLG9CQUE4QjtBQUFBLGtCQUMxQjtBQUlKLGtCQUFBQSxXQUFBLGtCQUFBLFdBQUEsS0FBQSxLQUFBO0FBSUEsd0JBQUEsZ0JBQUEsS0FBQTtBQUFBLG9CQUEyQjtBQUFBLGtCQUN2QjtBQUVKLGdDQUFBLFFBQUEsQ0FBQSxRQUFBO0FBQ0ksMEJBQUEsTUFBQSxJQUFBO0FBQ0Esd0JBQUEsT0FBQSxDQUFBLE9BQUEsU0FBQSxHQUFBLEdBQUE7QUFDSSw2QkFBQSxLQUFBLEdBQUE7QUFBQSxvQkFBZTtBQUFBLGtCQUNuQixDQUFBO0FBQUEsZ0JBQ0g7QUFHTCxvQkFBQUEsWUFBQSxPQUFBLFNBQUEsS0FBQSxZQUFBLFNBQUEsR0FBQTtBQUtJLHdCQUFBLFVBQUE7QUFBQSxvQkFTSTtBQUFBLG9CQUNBLFNBQUFBO0FBQUEsa0JBQ0E7QUFHSixzQkFBQSxPQUFBLFNBQUEsR0FBQTtBQUNJLDRCQUFBLFNBQUE7QUFBQSxrQkFBaUI7QUFHckIsc0JBQUEsWUFBQSxTQUFBLEdBQUE7QUFDSSw0QkFBQSxjQUFBO0FBQUEsa0JBQXNCO0FBRzFCLDJCQUFBLEtBQUEsT0FBQTtBQUFBLGdCQUFxQjtBQUFBLGNBQ3pCLENBQUE7QUFJSixvQkFBQSxVQUFBLFNBQUE7QUFBQSxnQkFBeUI7QUFBQSxjQUNyQjtBQUVKLHNCQUFBLFFBQUEsQ0FBQSxXQUFBO0FBQ0ksc0JBQUEsTUFBQSxPQUFBO0FBQ0Esc0JBQUEsU0FBQSxPQUFBO0FBR0Esb0JBQUEsVUFBQSxLQUFBO0FBQ0ksd0JBQUEsa0JBQUEsU0FBQSxPQUFBLENBQUEsTUFBQSxFQUFBLFNBQUEsTUFBQSxFQUFBLElBQUE7QUFHQSxzQkFBQSxtQkFBQSxnQkFBQSxhQUFBO0FBSUksMEJBQUEsYUFBQSxnQkFBQSxZQUFBO0FBQUEsc0JBQ2dDLENBQUEsTUFBQSxFQUFBLFNBQUE7QUFBQSxvQkFDTjtBQUUxQix3QkFBQSxjQUFBLENBQUEsV0FBQSxLQUFBO0FBQ0ksaUNBQUEsTUFBQTtBQUFBLG9CQUFpQjtBQUFBLGtCQUNyQjtBQUFBLGdCQUNKO0FBQUEsY0FDSixDQUFBO0FBSUoscUJBQUEsUUFBQSxNQUFBO0FBQUEsZ0JBQXFCO0FBQUEsa0JBQ2pCLFVBQUE7QUFBQSxvQkFDYztBQUFBLG9CQUNOO0FBQUEsb0JBQ0EsUUFBQTtBQUFBLGtCQUNRO0FBQUEsa0JBQ1osYUFBQTtBQUFBLGtCQUNhLGFBQUE7QUFBQSxnQkFDQTtBQUFBLGdCQUNqQixNQUFBO0FBRUkseUJBQUEsUUFBQSxZQUFBO0FBQUEsb0JBQTJCLFFBQUE7QUFBQSxrQkFDZixDQUFBO0FBRVosMEJBQUEsSUFBQSxvQkFBQSxRQUFBO0FBQUEsZ0JBQXdDO0FBQUEsY0FDNUM7QUFBQSxZQUNKLFNBQUEsT0FBQTtBQUVBLHNCQUFBLE1BQUEsK0JBQUEsS0FBQTtBQUNBLG9CQUFBLCtDQUFBO0FBQUEsWUFBcUQ7QUFBQSxVQUN6RCxDQUFBO0FBR0osa0JBQUEsSUFBQSw0Q0FBQTtBQUdBLGNBQUEscUJBQUE7QUFDSSwwQkFBQSxtQkFBQTtBQUNBLGtDQUFBO0FBQUEsVUFBc0I7QUFBQSxRQUMxQjtBQUFBLE1BQ0o7QUFJSixlQUFBLGlCQUFBO0FBQ0ksWUFBQSxTQUFBLFNBQUEsWUFBQTtBQUNJLGtCQUFBO0FBQUEsWUFBUTtBQUFBLFlBQ0o7QUFBQSxZQUNBO0FBQUEsWUFDQSxTQUFBO0FBQUEsVUFDUztBQUViLHVCQUFBLFNBQUE7QUFHQSxnQkFBQSxpQkFBQSxTQUFBO0FBQUEsWUFBZ0M7QUFBQSxVQUM1QjtBQUVKLGNBQUEsa0JBQUEsQ0FBQSxnQkFBQTtBQUNJLDJCQUFBLE9BQUE7QUFDQSxvQkFBQSxJQUFBLG1DQUFBO0FBQUEsVUFBK0M7QUFJbkQsY0FBQSxhQUFBLEdBQUE7QUFDSSxvQkFBQTtBQUFBLGNBQVE7QUFBQSxZQUNKO0FBR0osZ0JBQUEscUJBQUE7QUFDSSw0QkFBQSxtQkFBQTtBQUFBLFlBQWlDO0FBRXJDLGtDQUFBLE9BQUEsWUFBQSxNQUFBO0FBQ0ksaUNBQUE7QUFBQSxZQUFtQixHQUFBLEdBQUE7QUFJdkIsdUJBQUEsTUFBQTtBQUNJLGtCQUFBLHFCQUFBO0FBQ0ksOEJBQUEsbUJBQUE7QUFDQSxzQ0FBQTtBQUFBLGNBQXNCO0FBQUEsWUFDMUIsR0FBQSxJQUFBO0FBQUEsVUFDSTtBQUFBLFFBQ1o7QUFBQSxNQUNKO0FBSUosVUFBQSxhQUFBLEdBQUE7QUFDSSxnQkFBQSxJQUFBLG9EQUFBO0FBQ0EsOEJBQUEsT0FBQSxZQUFBLE1BQUE7QUFDSSw2QkFBQTtBQUFBLFFBQW1CLEdBQUEsR0FBQTtBQUl2QixtQkFBQSxNQUFBO0FBQ0ksY0FBQSxxQkFBQTtBQUNJLDBCQUFBLG1CQUFBO0FBQ0Esa0NBQUE7QUFBQSxVQUFzQjtBQUFBLFFBQzFCLEdBQUEsSUFBQTtBQUFBLE1BQ0k7QUFJWixZQUFBLFdBQUEsSUFBQSxpQkFBQSxNQUFBO0FBQ0ksdUJBQUE7QUFHQSxZQUFBLGFBQUEsS0FBQSxDQUFBLFNBQUEsY0FBQSxxQkFBQSxHQUFBO0FBSUksNkJBQUE7QUFBQSxRQUFtQjtBQUFBLE1BQ3ZCLENBQUE7QUFJSixlQUFBLFFBQUEsU0FBQSxNQUFBO0FBQUEsUUFBZ0MsV0FBQTtBQUFBLFFBQ2pCLFNBQUE7QUFBQSxNQUNGLENBQUE7QUFJYixrQkFBQSxnQkFBQSxHQUFBO0FBRUEsY0FBQSxJQUFBLHdEQUFBO0FBQUEsSUFBb0U7QUFBQSxFQUU1RSxDQUFBO0FDcFlPLFFBQU1DLFlBQVUsV0FBVyxTQUFTLFNBQVMsS0FDaEQsV0FBVyxVQUNYLFdBQVc7QUNGUixRQUFNLFVBQVVDO0FDRHZCLFdBQVNDLFFBQU0sV0FBVyxNQUFNO0FBRTlCLFFBQUksT0FBTyxLQUFLLENBQUMsTUFBTSxVQUFVO0FBQy9CLFlBQU0sVUFBVSxLQUFLLE1BQUE7QUFDckIsYUFBTyxTQUFTLE9BQU8sSUFBSSxHQUFHLElBQUk7QUFBQSxJQUNwQyxPQUFPO0FBQ0wsYUFBTyxTQUFTLEdBQUcsSUFBSTtBQUFBLElBQ3pCO0FBQUEsRUFDRjtBQUNPLFFBQU1DLFdBQVM7QUFBQSxJQUNwQixPQUFPLElBQUksU0FBU0QsUUFBTSxRQUFRLE9BQU8sR0FBRyxJQUFJO0FBQUEsSUFDaEQsS0FBSyxJQUFJLFNBQVNBLFFBQU0sUUFBUSxLQUFLLEdBQUcsSUFBSTtBQUFBLElBQzVDLE1BQU0sSUFBSSxTQUFTQSxRQUFNLFFBQVEsTUFBTSxHQUFHLElBQUk7QUFBQSxJQUM5QyxPQUFPLElBQUksU0FBU0EsUUFBTSxRQUFRLE9BQU8sR0FBRyxJQUFJO0FBQUEsRUFDbEQ7QUFBQSxFQ2JPLE1BQU0sK0JBQStCLE1BQU07QUFBQSxJQUNoRCxZQUFZLFFBQVEsUUFBUTtBQUMxQixZQUFNLHVCQUF1QixZQUFZLEVBQUU7QUFDM0MsV0FBSyxTQUFTO0FBQ2QsV0FBSyxTQUFTO0FBQUEsSUFDaEI7QUFBQSxJQUNBLE9BQU8sYUFBYSxtQkFBbUIsb0JBQW9CO0FBQUEsRUFDN0Q7QUFDTyxXQUFTLG1CQUFtQixXQUFXO0FBQzVDLFdBQU8sR0FBRyxTQUFTLFNBQVMsRUFBRSxJQUFJLFNBQTBCLElBQUksU0FBUztBQUFBLEVBQzNFO0FDVk8sV0FBUyxzQkFBc0IsS0FBSztBQUN6QyxRQUFJO0FBQ0osUUFBSTtBQUNKLFdBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS0wsTUFBTTtBQUNKLFlBQUksWUFBWSxLQUFNO0FBQ3RCLGlCQUFTLElBQUksSUFBSSxTQUFTLElBQUk7QUFDOUIsbUJBQVcsSUFBSSxZQUFZLE1BQU07QUFDL0IsY0FBSSxTQUFTLElBQUksSUFBSSxTQUFTLElBQUk7QUFDbEMsY0FBSSxPQUFPLFNBQVMsT0FBTyxNQUFNO0FBQy9CLG1CQUFPLGNBQWMsSUFBSSx1QkFBdUIsUUFBUSxNQUFNLENBQUM7QUFDL0QscUJBQVM7QUFBQSxVQUNYO0FBQUEsUUFDRixHQUFHLEdBQUc7QUFBQSxNQUNSO0FBQUEsSUFDSjtBQUFBLEVBQ0E7QUFBQSxFQ2ZPLE1BQU0scUJBQXFCO0FBQUEsSUFDaEMsWUFBWSxtQkFBbUIsU0FBUztBQUN0QyxXQUFLLG9CQUFvQjtBQUN6QixXQUFLLFVBQVU7QUFDZixXQUFLLGtCQUFrQixJQUFJLGdCQUFlO0FBQzFDLFVBQUksS0FBSyxZQUFZO0FBQ25CLGFBQUssc0JBQXNCLEVBQUUsa0JBQWtCLEtBQUksQ0FBRTtBQUNyRCxhQUFLLGVBQWM7QUFBQSxNQUNyQixPQUFPO0FBQ0wsYUFBSyxzQkFBcUI7QUFBQSxNQUM1QjtBQUFBLElBQ0Y7QUFBQSxJQUNBLE9BQU8sOEJBQThCO0FBQUEsTUFDbkM7QUFBQSxJQUNKO0FBQUEsSUFDRSxhQUFhLE9BQU8sU0FBUyxPQUFPO0FBQUEsSUFDcEM7QUFBQSxJQUNBLGtCQUFrQixzQkFBc0IsSUFBSTtBQUFBLElBQzVDLHFCQUFxQyxvQkFBSSxJQUFHO0FBQUEsSUFDNUMsSUFBSSxTQUFTO0FBQ1gsYUFBTyxLQUFLLGdCQUFnQjtBQUFBLElBQzlCO0FBQUEsSUFDQSxNQUFNLFFBQVE7QUFDWixhQUFPLEtBQUssZ0JBQWdCLE1BQU0sTUFBTTtBQUFBLElBQzFDO0FBQUEsSUFDQSxJQUFJLFlBQVk7QUFDZCxVQUFJLFFBQVEsUUFBUSxNQUFNLE1BQU07QUFDOUIsYUFBSyxrQkFBaUI7QUFBQSxNQUN4QjtBQUNBLGFBQU8sS0FBSyxPQUFPO0FBQUEsSUFDckI7QUFBQSxJQUNBLElBQUksVUFBVTtBQUNaLGFBQU8sQ0FBQyxLQUFLO0FBQUEsSUFDZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFjQSxjQUFjLElBQUk7QUFDaEIsV0FBSyxPQUFPLGlCQUFpQixTQUFTLEVBQUU7QUFDeEMsYUFBTyxNQUFNLEtBQUssT0FBTyxvQkFBb0IsU0FBUyxFQUFFO0FBQUEsSUFDMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFZQSxRQUFRO0FBQ04sYUFBTyxJQUFJLFFBQVEsTUFBTTtBQUFBLE1BQ3pCLENBQUM7QUFBQSxJQUNIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBTUEsWUFBWSxTQUFTLFNBQVM7QUFDNUIsWUFBTSxLQUFLLFlBQVksTUFBTTtBQUMzQixZQUFJLEtBQUssUUFBUyxTQUFPO0FBQUEsTUFDM0IsR0FBRyxPQUFPO0FBQ1YsV0FBSyxjQUFjLE1BQU0sY0FBYyxFQUFFLENBQUM7QUFDMUMsYUFBTztBQUFBLElBQ1Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFNQSxXQUFXLFNBQVMsU0FBUztBQUMzQixZQUFNLEtBQUssV0FBVyxNQUFNO0FBQzFCLFlBQUksS0FBSyxRQUFTLFNBQU87QUFBQSxNQUMzQixHQUFHLE9BQU87QUFDVixXQUFLLGNBQWMsTUFBTSxhQUFhLEVBQUUsQ0FBQztBQUN6QyxhQUFPO0FBQUEsSUFDVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBT0Esc0JBQXNCLFVBQVU7QUFDOUIsWUFBTSxLQUFLLHNCQUFzQixJQUFJLFNBQVM7QUFDNUMsWUFBSSxLQUFLLFFBQVMsVUFBUyxHQUFHLElBQUk7QUFBQSxNQUNwQyxDQUFDO0FBQ0QsV0FBSyxjQUFjLE1BQU0scUJBQXFCLEVBQUUsQ0FBQztBQUNqRCxhQUFPO0FBQUEsSUFDVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBT0Esb0JBQW9CLFVBQVUsU0FBUztBQUNyQyxZQUFNLEtBQUssb0JBQW9CLElBQUksU0FBUztBQUMxQyxZQUFJLENBQUMsS0FBSyxPQUFPLFFBQVMsVUFBUyxHQUFHLElBQUk7QUFBQSxNQUM1QyxHQUFHLE9BQU87QUFDVixXQUFLLGNBQWMsTUFBTSxtQkFBbUIsRUFBRSxDQUFDO0FBQy9DLGFBQU87QUFBQSxJQUNUO0FBQUEsSUFDQSxpQkFBaUIsUUFBUSxNQUFNLFNBQVMsU0FBUztBQUMvQyxVQUFJLFNBQVMsc0JBQXNCO0FBQ2pDLFlBQUksS0FBSyxRQUFTLE1BQUssZ0JBQWdCLElBQUc7QUFBQSxNQUM1QztBQUNBLGFBQU87QUFBQSxRQUNMLEtBQUssV0FBVyxNQUFNLElBQUksbUJBQW1CLElBQUksSUFBSTtBQUFBLFFBQ3JEO0FBQUEsUUFDQTtBQUFBLFVBQ0UsR0FBRztBQUFBLFVBQ0gsUUFBUSxLQUFLO0FBQUEsUUFDckI7QUFBQSxNQUNBO0FBQUEsSUFDRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFLQSxvQkFBb0I7QUFDbEIsV0FBSyxNQUFNLG9DQUFvQztBQUMvQ0MsZUFBTztBQUFBLFFBQ0wsbUJBQW1CLEtBQUssaUJBQWlCO0FBQUEsTUFDL0M7QUFBQSxJQUNFO0FBQUEsSUFDQSxpQkFBaUI7QUFDZixhQUFPO0FBQUEsUUFDTDtBQUFBLFVBQ0UsTUFBTSxxQkFBcUI7QUFBQSxVQUMzQixtQkFBbUIsS0FBSztBQUFBLFVBQ3hCLFdBQVcsS0FBSyxPQUFNLEVBQUcsU0FBUyxFQUFFLEVBQUUsTUFBTSxDQUFDO0FBQUEsUUFDckQ7QUFBQSxRQUNNO0FBQUEsTUFDTjtBQUFBLElBQ0U7QUFBQSxJQUNBLHlCQUF5QixPQUFPO0FBQzlCLFlBQU0sdUJBQXVCLE1BQU0sTUFBTSxTQUFTLHFCQUFxQjtBQUN2RSxZQUFNLHNCQUFzQixNQUFNLE1BQU0sc0JBQXNCLEtBQUs7QUFDbkUsWUFBTSxpQkFBaUIsQ0FBQyxLQUFLLG1CQUFtQixJQUFJLE1BQU0sTUFBTSxTQUFTO0FBQ3pFLGFBQU8sd0JBQXdCLHVCQUF1QjtBQUFBLElBQ3hEO0FBQUEsSUFDQSxzQkFBc0IsU0FBUztBQUM3QixVQUFJLFVBQVU7QUFDZCxZQUFNLEtBQUssQ0FBQyxVQUFVO0FBQ3BCLFlBQUksS0FBSyx5QkFBeUIsS0FBSyxHQUFHO0FBQ3hDLGVBQUssbUJBQW1CLElBQUksTUFBTSxLQUFLLFNBQVM7QUFDaEQsZ0JBQU0sV0FBVztBQUNqQixvQkFBVTtBQUNWLGNBQUksWUFBWSxTQUFTLGlCQUFrQjtBQUMzQyxlQUFLLGtCQUFpQjtBQUFBLFFBQ3hCO0FBQUEsTUFDRjtBQUNBLHVCQUFpQixXQUFXLEVBQUU7QUFDOUIsV0FBSyxjQUFjLE1BQU0sb0JBQW9CLFdBQVcsRUFBRSxDQUFDO0FBQUEsSUFDN0Q7QUFBQSxFQUNGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7IiwieF9nb29nbGVfaWdub3JlTGlzdCI6WzAsMiwzLDQsNSw2LDddfQ==
content;